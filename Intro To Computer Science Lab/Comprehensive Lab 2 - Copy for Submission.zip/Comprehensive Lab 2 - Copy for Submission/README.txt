----------------------------------------------------------------------------------------------------------
Within this folder, you will find Lab Files, and a "Porject" folder that only contains Java Source Files. 
The location of the CSV Files is NOT incorrect. The location of the files is correct.
In the "Project" folder, you will find two source code files: CL2_Main.java and CL2_MethodTesting.java
----------------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------------
CL2_Main.java:
	This file is the actual lab coded project that we have to turn in
CL2_MethodTesting:
	This file is the code used to test the outputs of the methods, in order to evaluate functionality
----------------------------------------------------------------------------------------------------------